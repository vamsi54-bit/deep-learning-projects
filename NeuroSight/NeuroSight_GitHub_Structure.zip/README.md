# NeuroSight

Brain Tumor Classification with future Segmentation Module.

## Structure
- models/
- training/
- api/
- utils/
- app/

This repository was split from the original single-file implementation.
