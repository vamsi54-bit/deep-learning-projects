# Move segmentation training loop here
