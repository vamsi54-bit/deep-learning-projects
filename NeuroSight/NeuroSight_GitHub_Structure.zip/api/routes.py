# Move FastAPI routes here
