# Move inference helpers here
